ReadME:
The codes have not been segregated chapter-wise as the projects made in different chapters are connected.