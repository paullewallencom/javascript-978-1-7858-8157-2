/**
 * console.assert example
 */
console.assert( sessionId > 0, "Session is created" );