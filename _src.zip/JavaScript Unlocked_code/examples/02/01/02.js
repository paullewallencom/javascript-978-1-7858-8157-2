/**
 * Module import
 */
(function ( $, Backbone ) {
   "use strict";
  // module body
}( jQuery, Backbone ));