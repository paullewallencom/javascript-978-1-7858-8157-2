/**
 * Module export
 */
(function ( window, undefined ) {
   "use strict";
  // module body
}( window ));