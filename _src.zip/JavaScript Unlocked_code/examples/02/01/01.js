/**
 * IFE (Immediately Invoked Function Expression):
 */
(function () {
  "use strict";
   // variable defined inside this scope cannot be accessed from outside
}());