babel --modules common *.es6 --out-dir .
cjsc main.js -o bundle.js -M