"use strict";

var _foo = require("./foo");

document.writeln(_foo.bar); // bar
document.writeln(_foo.baz); // baz