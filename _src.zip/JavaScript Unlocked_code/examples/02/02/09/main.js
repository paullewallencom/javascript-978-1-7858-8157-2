var Foo = require( "./foo" ),
    foo = new Foo();
console.log( foo.bar ); // bar