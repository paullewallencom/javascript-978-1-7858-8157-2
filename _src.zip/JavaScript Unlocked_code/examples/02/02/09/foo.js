var Foo = function(){
  this.bar = "bar";
};
module.exports = Foo;