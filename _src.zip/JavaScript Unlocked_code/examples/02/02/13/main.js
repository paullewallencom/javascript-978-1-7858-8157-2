"use strict";

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

var _foo = require("./foo");

var _foo2 = _interopRequireDefault(_foo);

console.log((0, _foo2["default"])()); // foo