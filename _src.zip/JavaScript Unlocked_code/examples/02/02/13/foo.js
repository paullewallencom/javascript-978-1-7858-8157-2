"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = foo;

function foo() {
  return "foo";
}

;
module.exports = exports["default"];