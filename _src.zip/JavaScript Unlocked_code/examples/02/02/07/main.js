var first = require( "./foo" ),
    second = require( "./foo" );
console.log( first === second ); // true