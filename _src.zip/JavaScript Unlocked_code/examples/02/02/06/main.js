require( "./foo" );
require( "./foo" );
require( "./foo" );