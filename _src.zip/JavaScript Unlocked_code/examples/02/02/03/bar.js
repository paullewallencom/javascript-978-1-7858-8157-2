define({
  value: "bar"
});