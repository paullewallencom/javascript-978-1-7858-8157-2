define({
  value: "baz"
});