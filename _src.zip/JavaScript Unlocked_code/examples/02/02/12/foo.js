"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var bar = "bar";
exports.bar = bar;
var baz = "baz";
exports.baz = baz;