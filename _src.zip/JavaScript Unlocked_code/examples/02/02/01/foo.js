define({
  bar: "bar",
  baz: "baz"
});