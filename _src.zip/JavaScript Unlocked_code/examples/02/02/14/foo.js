"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.setBar = setBar;
var bar = "bar";
exports.bar = bar;

function setBar(val) {
	exports.bar = bar = val;
}

;