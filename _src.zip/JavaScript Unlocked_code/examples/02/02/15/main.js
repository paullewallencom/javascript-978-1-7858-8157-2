var foo = require( "./foo" );
console.log( foo.bar ); // bar