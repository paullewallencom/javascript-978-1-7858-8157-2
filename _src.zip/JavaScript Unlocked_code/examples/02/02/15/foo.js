// module logic
module.exports = {
  bar: require( "./bar" )
};