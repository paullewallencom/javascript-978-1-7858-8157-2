require( "./foo" );
console.log( typeof foo ); // undefined