var foo = require( "./foo" );
document.writeln( foo.bar ); // bar
console.log(1);