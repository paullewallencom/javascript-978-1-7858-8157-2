// module logic
module.exports = "baz";