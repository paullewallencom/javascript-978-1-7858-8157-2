// module logic
module.exports = "bar";