// module logic
module.exports = {
  bar: require( "./bar" ),
  baz: require( "./baz" )
};