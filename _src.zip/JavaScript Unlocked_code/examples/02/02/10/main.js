var foo = require( "./foo" );
console.log( foo.bar ); // bar
console.log( foo.baz ); // baz