/**
 * Fat-arrow function with return
 */
var res  = [ 1, 2, 3, 4 ].filter( v => v > 2 );
console.log( res ); // [3,4]