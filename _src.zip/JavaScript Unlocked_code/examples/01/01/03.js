/**
 * Conditional invocation 2
 */
/**
 * @param {Function} [cb] - callback
 */
function fn( cb ) {
  cb && cb();
}