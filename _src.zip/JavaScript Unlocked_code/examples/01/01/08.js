/**
 * ES6 method definition
 */
let foo = {
  bar ( param1, param2 ) {
  }
}