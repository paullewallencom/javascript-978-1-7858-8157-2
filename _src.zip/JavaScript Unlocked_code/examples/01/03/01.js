/**
 * forEach example
 */
"use strict";
var data = [ "bar", "foo", "baz", "qux" ];
data.forEach(function( val ){
   console.log( val );
});