/**
 * Multi-line string via concatenation
 */
var str = "Lorem ipsum dolor sit amet, \n" +
  "consectetur adipiscing elit. Nunc ornare,\n" +
  "diam ultricies vehicula aliquam, mauris \n" +
  "ipsum dapibus dolor, quis fringilla leo ligula non neque";