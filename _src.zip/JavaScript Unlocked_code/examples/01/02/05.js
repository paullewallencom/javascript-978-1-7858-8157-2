/**
 * Template usage example
 */
"use strict";
var title = "Some title",
    text = "Some text",
    str = `<div class="message">
<h2>${title}</h2>
<article>${text}</article>
</div>`;
console.log( str );