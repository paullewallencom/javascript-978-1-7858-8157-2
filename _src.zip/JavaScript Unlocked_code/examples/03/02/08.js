/**
 * Learning Fetch API #1
 */
fetch( "/rest/foo", {
	headers: {
		"Accept": "application/json",
    "Content-Type": "application/json"
	}
});