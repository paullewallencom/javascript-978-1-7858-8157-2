/**
 * Insert elements into DOM #2
 */
var target = document.getElementById( "target" );
target.innerHTML = "<div></div>";