/**
 * Accessing multipart data-attribures
 */
console.log( el.dataset.fooBarBaz );
el.dataset.fooBarBaz = "foo-bar-baz";