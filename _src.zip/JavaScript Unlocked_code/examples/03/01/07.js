/**
 * Testing if a found element matches a given selector
 */
console.log( el.matches( ".foo > .bar" ) );
console.log( input.matches( ":checked" ) );