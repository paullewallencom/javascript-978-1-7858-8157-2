/**
 * Style via style.cssText
 */
el.style.cssText = "color:red;font-family: Arial;font-size: 1.2rem;";