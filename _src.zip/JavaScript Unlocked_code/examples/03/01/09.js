/**
 * Insert elements into DOM #2
 */
var target = document.getElementById( "target" ),
    div = document.createElement( "div" );
target.appendChild( div );