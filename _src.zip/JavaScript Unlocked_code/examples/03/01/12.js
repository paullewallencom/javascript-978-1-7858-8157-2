/**
 * Remove element from the DOM
 */
el.parentNode.removeChild( el );