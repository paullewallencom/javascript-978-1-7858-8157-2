/**
 * Remove event listener
 */
btn.removeEventListener( "click", onClick );