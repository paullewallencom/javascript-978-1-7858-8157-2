/**
 * Styling via style property
 */
el.style.color = "red";
el.style.fontFamily = "Arial";
el.style.fontSize = "1.2rem";