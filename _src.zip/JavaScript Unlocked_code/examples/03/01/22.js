/**
 * Accessing data-attribures
 */
console.log( el.dataset.foo );
el.dataset.foo = "foo";