/**
 * Navigating DOM tree using node relationships
 */
console.log( el.children );
console.log( el.parentNode );
console.log( el.nextElementSibling );