/**
 * Injecting element to a specified position
 */
parent.insertBefore( el, parent.firstChild );