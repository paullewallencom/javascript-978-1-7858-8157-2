// attribute
console.log( input.getAttribute( "value" ) );
// property
console.log( input.value );