var foo = require( "./foo" );
console.log( "Running main.js" );
console.log( "Exported value:", foo );