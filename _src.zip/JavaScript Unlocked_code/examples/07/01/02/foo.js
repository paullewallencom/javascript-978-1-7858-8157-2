console.log( "Running foo.js" );
module.exports = "foo";