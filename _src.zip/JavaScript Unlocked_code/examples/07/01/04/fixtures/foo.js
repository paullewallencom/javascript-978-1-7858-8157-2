/**
 * @copyright 2015 AwesomeCompany
 * jscs standard:Jquery
 */
 var foo = "foo";