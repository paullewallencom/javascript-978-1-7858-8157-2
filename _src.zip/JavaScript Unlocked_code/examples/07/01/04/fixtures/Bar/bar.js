/**
 * @copyright 2010 AwesomeCompany
 * jscs standard:Jquery
 */
 var bar = "bar";