/**
 * Simple send to stdout in nodejs
 */
console.log( "Hello world!" );